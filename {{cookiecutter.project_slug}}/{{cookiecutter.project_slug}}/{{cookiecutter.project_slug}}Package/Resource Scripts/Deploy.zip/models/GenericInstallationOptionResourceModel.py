class GenericInstallationOptionResourceModel(object):
    def __init__(self):
        self.generic_input = ''
