class VLANManualResourceModel(object):
    def __init__(self):
        self.access_mode = ''
        self.isolation_level = ''
        self.virtual_network = ''
        self.virtual_network_attribute = ''
        self.vlan_id = ''
