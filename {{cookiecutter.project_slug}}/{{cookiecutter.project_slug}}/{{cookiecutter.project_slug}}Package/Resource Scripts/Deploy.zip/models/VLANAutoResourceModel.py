class VLANAutoResourceModel(object):
    def __init__(self):
        self.access_mode = ''
        self.allocation_ranges = ''
        self.isolation_level = ''
        self.virtual_network = ''
        self.virtual_network_attribute = ''
        self.vlan_id = ''
