class GenericAppModelResourceModel(object):

    def __init__(self):
        self.vm_uuid = ''
        self.cloud_provider = ''
