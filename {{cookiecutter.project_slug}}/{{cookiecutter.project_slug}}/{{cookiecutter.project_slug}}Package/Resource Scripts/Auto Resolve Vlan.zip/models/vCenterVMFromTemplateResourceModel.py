class vCenterVMFromTemplateResourceModel(object):
    def __init__(self):
        self.vcenter_name = ''
        self.vcenter_template = ''
        self.vm_cluster = ''
        self.vm_storage = ''
        self.ip_regex = ''
        self.vm_resource_pool = ''
        self.vm_location = ''
        self.auto_power_on = ''
        self.auto_power_off = ''
        self.wait_for_ip = ''
        self.auto_delete = ''
