class TempCommandConnectorModelResourceModel(object):
    pass
