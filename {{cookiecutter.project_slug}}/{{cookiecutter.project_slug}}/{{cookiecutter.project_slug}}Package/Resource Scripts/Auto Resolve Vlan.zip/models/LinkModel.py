class LinkModel(object):
    def __init__(self):
        self.target_interface = ''
