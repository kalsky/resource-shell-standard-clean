﻿class VMClusterModel(object):

    def __init__(self, cluster_name, resource_pool):
        self.cluster_name = cluster_name
        self.resource_pool = resource_pool


