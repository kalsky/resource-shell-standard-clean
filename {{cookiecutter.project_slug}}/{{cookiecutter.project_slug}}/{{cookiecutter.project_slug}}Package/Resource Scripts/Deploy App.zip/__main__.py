from orchestrator import execute_app_orchestration


def main():
    execute_app_orchestration()


if __name__ == "__main__":
    main()
